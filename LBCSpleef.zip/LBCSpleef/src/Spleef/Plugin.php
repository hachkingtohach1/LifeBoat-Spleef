<?php

namespace Spleef;

use pocketmine\level\Level;
use pocketmine\math\AxisAlignedBB;
use pocketmine\plugin\PluginBase;
use Spleef\gadget\GadgetManager;
use Spleef\game\GameManager;
use Spleef\game\GameMapSourceInfo;
use Spleef\task\TeleportTask;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\math\Vector3;
use pocketmine\utils\Config;
use Spleef\DatabaseManager;
use Spleef\player\CooldownTickTask;
use Spleef\player\NotificationTickTask;
use LbCore\language\Translate;
use Kits\Kit;
use Logger\Logger;

/**
 * Base plugin class with onEnable method which contains autoload options
 */
class Plugin extends PluginBase {

	/* @var Plugin */
	public static $instance = null;
	/* @var bool - use it to enable testing mode and play on arena alone*/
	public $testing = false;
	/* @var Config|null */
	public $config = null;
	/* @var DatabaseManager */
	public $dbManager;
	/* @var GameManager */
	public $gameManager;
	/* @var GadgetManager */
	public $gadgetManager;
	/* @var Area */ 
	public $lobbyArea;
	/* @var Level */
	public $level;
	/* @var int */
	public $gameCountdown;
	/* @var string */
	public $serverGameType = "";
	/* @var string */
	public $serverGameTypeShort = "";

	/**
	 * Main method to call events, save fields and create autoload objects (as managers)
	 */
	public function onEnable() {
		//create custom plugin translations
		Translate::getInstance()->createTranslations('Spleef\language\\');
		self::$instance = $this;
		//stop level time
		$this->level = $this->getServer()->getLevelByName("world");
		$this->level->stopTime = true;
		$this->level->setTime(1200);
		$this->level->setAutoSave(false);
		//create base plugin config
		$config = new Config("worlds/" . $this->level->getFolderName() . "/config.yml", Config::YAML);
		$this->config = $config;

		$this->serverGameType = $config->get("gametype");
		$this->serverGameTypeShort = $config->get("gametypeShort");
		//create managers
		$this->dbManager = new DatabaseManager($this);
		$this->gameManager = new GameManager($this);
		$this->gadgetManager = new GadgetManager($this);

		$lobbyConfig = $config->get("lobby");
		$this->lobbyArea = new Area(
				$this, 
				$lobbyConfig["posX"], 
				$lobbyConfig["posY"], 
				$lobbyConfig["posZ"], 
				$lobbyConfig["size"], 
				$lobbyConfig["kickSize"], 
				false, 
				$lobbyConfig["time"], 
				false, 
				true);
		//set game countdown
		$this->gameCountdown = $this->testing ? 3 : $config->get("gameCountdown");
		//set game positions
		for ($i = 2; $i < 10; $i++) {
			$this->gameManager->gamePositions[] = new Vector3($this->lobbyArea->centerX + $i * 600, 100, $this->lobbyArea->centerZ + $i * 600);
			$this->gameManager->gamePositions[] = new Vector3($this->lobbyArea->centerX + $i * 600, 100, $this->lobbyArea->centerZ - $i * 600);
			$this->gameManager->gamePositions[] = new Vector3($this->lobbyArea->centerX - $i * 600, 100, $this->lobbyArea->centerZ + $i * 600);
			$this->gameManager->gamePositions[] = new Vector3($this->lobbyArea->centerX - $i * 600, 100, $this->lobbyArea->centerZ - $i * 600);
			$this->gameManager->gamePositions[] = new Vector3($this->lobbyArea->centerX, 100, $this->lobbyArea->centerZ + $i * 600);
			$this->gameManager->gamePositions[] = new Vector3($this->lobbyArea->centerX, 100, $this->lobbyArea->centerZ - $i * 600);
			$this->gameManager->gamePositions[] = new Vector3($this->lobbyArea->centerX + $i * 600, 100, $this->lobbyArea->centerZ);
			$this->gameManager->gamePositions[] = new Vector3($this->lobbyArea->centerX - $i * 600, 100, $this->lobbyArea->centerZ);
		}
		//save info for each game mode
		$games = $config->get("games");
		foreach ($games as $gameInfo) {
			$s = new GameMapSourceInfo();
			$gameType = isset($gameInfo["game"]) ? $gameInfo["game"] : $this->serverGameType;
			$y = isset($gameInfo["spawnY"]) ? $gameInfo["spawnY"] : 100;
			$s->pos = new Vector3($gameInfo["x"], $y, $gameInfo["z"]);
			$s->size = $gameInfo["size"];
			$s->kickSize = $gameInfo["kickSize"];
			$s->minPlayers = $gameInfo["minPlayers"];
			$s->maxPlayers = $gameInfo["maxPlayers"];
			$gamePositions = [];
			$gamePositionsInfo = $gameInfo["positions"];
			foreach ($gamePositionsInfo as $id => $positionInfo) {
				$positionX = $positionInfo["x"];
				$positionY = isset($positionInfo["spawnY"]) ? $positionInfo["spawnY"] : $y;
				$positionZ = $positionInfo["z"];
				$gamePositions[$id - 1] = new Vector3($positionX, $positionY, $positionZ);
			}
			$s->positions = $gamePositions;

			for ($x = ($s->pos->x - $s->size) >> 4; $x <= ($s->pos->x + $s->size) >> 4; $x++) {
				for ($z = ($s->pos->z - $s->size) >> 4; $z <= ($s->pos->z + $s->size) >> 4; $z++) {
					$chunk = $this->level->getChunk($x, $z, true);
					$data = [$chunk->getBlockIdArray(), $chunk->getBlockDataArray(), $chunk->getBlockLightArray(), $chunk->getBlockSkyLightArray(), $chunk->getBiomeColorArray(), $chunk->getHeightMapArray()];
					$s->chunks[Level::chunkHash($x, $z)] = $data;
					$this->level->unloadChunk($x, $z, false);
				}
			}

			if (!isset($this->gameManager->sourcePositions[$gameType])) {
				$this->gameManager->sourcePositions[$gameType] = [];
			}
			$this->gameManager->sourcePositions[$gameType][] = $s;
		}
		//get teleports
		$teleports = [];
		$teleportsConfig = $config->get("teleports");

		foreach ($teleportsConfig as $teleport) {
			$teleportInfo = array();
			$enterX = $teleport["enterX"];
			$enterY = $teleport["enterY"];
			$enterZ = $teleport["enterZ"];
			$enterX2 = $teleport["enterX2"];
			$enterY2 = $teleport["enterY2"];
			$enterZ2 = $teleport["enterZ2"];
			$teleportInfo["aabb"] = new AxisAlignedBB($enterX, $enterY, $enterZ, $enterX2, $enterY2, $enterZ2);
			$teleportInfo["game"] = $teleport["game"];
			array_push($teleports, $teleportInfo);
		}
		//create repeating tasks and listener
		$this->getServer()->getScheduler()->scheduleRepeatingTask(new TeleportTask($this, $teleports), 20);		
		$this->getServer()->getScheduler()->scheduleRepeatingTask(new CooldownTickTask($this), 10);
		$this->getServer()->getScheduler()->scheduleRepeatingTask(new NotificationTickTask($this), 20);
		$this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);
		// enable kits
		Kit::enable($this);
		//enable pets
		$this->getServer()->getPluginManager()->registerEvents(new \Pets\PetsManager($this), $this);
		Logger::getInstance()->initCurrentGameType('sp');
	}

	public function onDisable() {
		self::$instance = null;
	}
		
	/**
	 * Use this method to add specific plugin commands,
	 * now only /lobby here (return player to lobby)
	 * 
	 * @param CommandSender $sender
	 * @param Command $command
	 * @param $label
	 * @param array $args
	 * @return boolean
	 */
	public function onCommand(CommandSender $sender, Command $command, $label, array $args) {
		if (strtolower($command->getName()) === "lobby") {
			$sender->returnToLobby();
			return true;
		}
	}

}

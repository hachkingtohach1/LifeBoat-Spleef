<?php

namespace Spleef\gadget;

use pocketmine\entity\Entity;
use pocketmine\item\Item;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\Compound;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\Enum;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\utils\TextFormat;
use Spleef\player\CustomPlayer;

/** This class manages Explode Item */
class ExplodeItem_1 extends ActionItem {

	public $slot;

	/**
	 * 
	 * @param type $slot
	 * @param type $count
	 */
	public function __construct($slot, $count) {
		$this->slot = $slot;
		parent::__construct(Item::TNT, 0, $count, TextFormat::RED . "Explosive", "Tap again to drop a primed TNT");
	}

	/**
	 * Manages the item use by specified player
	 * 
	 * @param CustomPlayer $player
	 */
	public function useItem(CustomPlayer $player) {
		parent::useItem($player);

		$tnt = Entity::createEntity("PrimedTNT", $player->getLevel()->getChunk($player->x >> 4, $player->z >> 4), new Compound("", [
					"Pos" => new Enum("Pos", [
						new DoubleTag("", $player->x + 0.5),
						new DoubleTag("", $player->y),
						new DoubleTag("", $player->z + 0.5)
							]),
					"Motion" => new Enum("Motion", [
						new DoubleTag("", 0),
						new DoubleTag("", 0),
						new DoubleTag("", 0)
							]),
					"Rotation" => new Enum("Rotation", [
						new FloatTag("", 0),
						new FloatTag("", 0)
							]),
					"Fuse" => new ByteTag("Fuse", 40)
		]));
		$tnt->spawnToAll();

		$this->setCount($this->count - 1);
		$player->getInventory()->setItem($this->slot, $this);
	}

}

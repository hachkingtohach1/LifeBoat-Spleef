<?php

namespace Spleef\gadget;

use pocketmine\event\Listener;
use pocketmine\plugin\Plugin;
use pocketmine\block\Block;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\math\Vector3;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\level\Explosion;
use pocketmine\level\Position;
use pocketmine\event\entity\EntityDamageEvent;

/**
 * Describes VIP bonus mines logic
 */
class Mine implements Listener {

	const PRODUCT_ID = Block::CARPET;
	const PRODUCT_COLOR = 0;
	const EXPLOSION_RADIUS = 1;

	/** @var Plugin */
	private $plugin;

	/**
	 * Constructor, register events
	 * 
	 * @param Plugin $plugin
	 */
	public function __construct(Plugin $plugin) {
		$this->plugin = $plugin;
		$plugin->getServer()->getPluginManager()->registerEvents($this, $plugin);
	}

	/**
	 * Check if player is on carpet block - destroy carpet and block under it
	 * 
	 * @param PlayerInteractEvent $event
	 */
	public function onPlayerMove(PlayerMoveEvent $event) {
		$player = $event->getPlayer();
		$level = $this->plugin->getServer()->getDefaultLevel();

		for ($i = -1; $i < 2; $i++) {
			for ($j = -1; $j < 2; $j++) {
				$block = $level->getBlock(new Vector3($player->x + $i, $player->y, $player->z + $j));
				if ($block->getId() == Block::CARPET) {
					$level->setBlock(new Vector3($block->x, $block->y, $block->z), Block::get(Block::AIR), true);
					$explosion = new Explosion(new Position($block->x, $block->y, $block->z, $level), self::EXPLOSION_RADIUS);
					// explode blocks
//					$explosion->explodeA();
					// explode entities
					$explosion->explodeB();

					for ($x = -1; $x <= 1; $x++) {
						for ($y = -1; $y <= 1; $y++) {
							for ($z = -1; $z <= 1; $z++) {
								$level->setBlock(
										new Vector3($block->x + $x, $block->y + $y - 1, $block->z + $z), Block::get(Block::AIR), true
								);
							}
						}
					}
				}
			}
		}
	}

	/**
	 * Used to set carpet in game
	 * 
	 * @param EntityDamageEvent $event
	 */
	public function onBlockPlace(BlockPlaceEvent $event) {
		$block = $event->getBlock();
		$player = $event->getPlayer();
		$item = $event->getItem();
		$downBlock = $event->getBlockAgainst();

		if ($item->getId() === self::PRODUCT_ID) {
			$event->setCancelled(true);
			if (!is_null($player->currentGame) && $player->currentGame->isStarted && !(
					$downBlock instanceof \pocketmine\block\Carpet || $downBlock instanceof \pocketmine\block\Air
					)) {

				$this->plugin->getServer()->getDefaultLevel()->setBlock(
						new Vector3($block->x, $block->y, $block->z), $block
				);
			}
		}
	}

	/**
	 * Cancel damage from carpet explosion
	 * 
	 * @param EntityDamageEvent $event
	 */
	public function onEntityDamage(EntityDamageEvent $event) {
		$player = $event->getEntity();

		if ($player instanceof \pocketmine\Player) {
			if (!is_null($player->currentGame) &&
					$player->currentGame->isStarted &&
					$event->getCause() == EntityDamageEvent::CAUSE_BLOCK_EXPLOSION) {

				$event->setCancelled(true);
			}
		}
	}

}

<?php

namespace Spleef\task;

use pocketmine\scheduler\PluginTask;
use Spleef\Plugin;
use Spleef\player\CustomPlayer;

/**
 * TeleportTask handles teleporting between areas and lobby 
 * (when player came to a wall)
 */
class TeleportTask extends PluginTask {

	/** @var Plugin */
	private $plugin;
	/** @var TeleportManager */
	private $teleports;

	/**
	 * 
	 * @param Plugin $plugin
	 * @param $teleports
	 */
	public function __construct(Plugin $plugin, $teleports) {
		parent::__construct($plugin);
		$this->plugin = $plugin;
		$this->teleports = $teleports;
	}

	/**
	 * Executes all teleports
	 * 
	 * @param int $currentTick
	 */
	public function onRun($currentTick) {
		foreach ($this->teleports as $teleport) {
			$r = $this->plugin->level->getCollidingEntities($teleport["aabb"]);
			foreach ($r as $entity) {
				if (!($entity instanceof CustomPlayer) || !$entity->isOnline() || $entity->currentGame !== null) {
					continue;
				}
				//check for login
				if ($entity->isRegistered() && !$entity->isAuthorized()) {
					$entity->sendMessage($entity->getTranslatedString("NEEDS_LOGIN"));
					continue;
				}
				
				$aabb = $teleport["aabb"];
				if ($aabb !== null && !$aabb->intersectsWith($entity->getBoundingBox())) {
					continue;
				}
				//add player to chosen game mode
				$entity->joinGame($teleport["game"]);
			}
		}
	}

}

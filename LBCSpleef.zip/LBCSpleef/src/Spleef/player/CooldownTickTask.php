<?php

namespace Spleef\player;

use pocketmine\scheduler\PluginTask;

/**
 * Handles cooldown before player can use bonus items again
 */
class CooldownTickTask extends PluginTask {

	public function onRun($currentTick) {
		foreach ($this->getOwner()->getServer()->getOnlinePlayers() as $player) {
			if ($player instanceof CustomPlayer) {
				$player->cooldownTick();
			}
		}
	}

}

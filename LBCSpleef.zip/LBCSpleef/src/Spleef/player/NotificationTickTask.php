<?php

namespace Spleef\player;

use pocketmine\utils\TextFormat;
use Spleef\Plugin;
use pocketmine\scheduler\PluginTask;

/**
 * Send popup notifications to each player,
 * depends on current player area (lobby or map) and player status (is or not registered)
 */
class NotificationTickTask extends PluginTask {

	/** @var Plugin */
	private $plugin;

	/**
	 * Class constructor
	 * 
	 * @param Plugin $plugin
	 */
	public function __construct(Plugin $plugin) {
		parent::__construct($plugin);
		$this->plugin = $plugin;
	}

	/**
	 * Show notification to online players
	 * 
	 * @param int $currentTick
	 */
	public function onRun($currentTick) {
		foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
			if ($player->spawned && $player instanceof CustomPlayer) {
				if ($player->hasNotification !== false) {
					//game mode notification
					$player->sendTip($player->hasNotification);
					if ($player->notificationTime >= 0) {
						$player->notificationTime--;

						if ($player->notificationTime === 0) {
							$player->showNotification(null);
						}
					}
				} else if ($player->currentGame === null) {
					//lobby notififcations
					$welcome = $player->getTranslatedString("WELCOME_TO_LIFEBOAT", "", array($this->plugin->serverGameType));
					$account_status = "";
					if ($player->isAuthorized()) {
						$account_status = TextFormat::YELLOW . $player->getDisplayName() . TextFormat::GRAY . " | " . TextFormat::GOLD . number_format($player->coinsNum) . $player->getTranslatedString("JUST_COINS");
					} else if (!$player->isRegistered()) {
						$account_status = $player->getTranslatedString("ACC_NOT_REGISTERED");
					}
					
					$player->sendTip($welcome . "\n" . $account_status);
				}
			}
		}
	}

}

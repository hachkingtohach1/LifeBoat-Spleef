<?php

namespace Spleef\game\modes\Spleef;

use pocketmine\entity\Effect;
use Spleef\Area;
use Spleef\game\Game;
use Spleef\game\GameManager;
use Spleef\game\GameMapSourceInfo;
use Spleef\Plugin;
use Spleef\gadget\Mine;
use Spleef\gadget\GadgetItem;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat;
use pocketmine\block\Block;
use Spleef\player\CustomPlayer;

/** This class manages base Spleef game type */
class SpleefGame extends Game {
	/** @var string*/
	public static $type = "Spleef";
	/** @var int*/
	public $noDamageTime = 1;
	/** @var int */
	public $multipleDeaths = 0;
	/** @var int */
	public $coinsForParticipation = 0;
	/** @var int */
	public $coinsForWinning = 2;
	/** @var int */
	public $coinsForKill = 1;
	/** @var int */
	public $coinsForAssist = 1;
	/** @var bool */
	public $allowDroppedItems = false;

	/**
	 * SpleefGame class constructor
	 * 
	 * @param Plugin $plugin
	 * @param GameManager $gameManager
	 * @param type $name
	 * @param Area $gameArea
	 * @param GameMapSourceInfo $source
	 * @param int $minPlayers
	 * @param int $maxPlayers
	 */
	public function __construct(Plugin $plugin, GameManager $gameManager, $name, Area $gameArea, GameMapSourceInfo $source, $minPlayers, $maxPlayers) {
		parent::__construct($plugin, $gameManager, $name, $gameArea, $source, $minPlayers, $maxPlayers);
	}

	/**
	 * Executes when countdown finished:
	 * - add haste effect,
	 * - give mines for VIP players
	 */
	public function countdownFinished() {
		foreach ($this->players as $player) {
			$player->addEffect(Effect::getEffect(Effect::HASTE)->setAmplifier(127)->setDuration(0x7fffffff)->setVisible(false));
			if ($player->isVip()) {
				$player->setHotbarAction(6, new GadgetItem(Item::CARPET, 0, 25, Mine::PRODUCT_ID, "Mine", TextFormat::GOLD));
			}
		}
		$this->isStarted = true;
	}
	
	/**
	 * Use it to add specific bonus blocks on maps
	 * 
	 * @param Block $block
	 * @param CustomPlayer $player
	 */
	public function spleefBlockDestroyed(Block $block, CustomPlayer $player) {
		
	}

}

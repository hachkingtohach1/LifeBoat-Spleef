<?php

namespace Spleef\game\modes\Spleef;

use pocketmine\block\Block;
use pocketmine\entity\Effect;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat;
use Spleef\gadget\NamedItem;
use Spleef\player\CustomPlayer;
use Spleef\gadget\SlowBombItem;
use Spleef\gadget\ExplodeItem_1;

/** This class manages Pizza Spleef game type */
class PizzaSpleefGame extends SpleefGame {

	public static $type = "PizzaSpleef";

	/**
	 * Executes when countdown finished. 
	 * Adds diamond pickaxe for all players
	 */
	public function countdownFinished() {
		parent::countdownFinished();
		foreach ($this->players as $player) {
			$player->setHotbarAction(
					0, new NamedItem(Item::DIAMOND_PICKAXE, 0, 1, $player->getTranslatedString("PIZZA_CUTTER", TextFormat::RED))
			);
			$player->setStateInGame();
		}
	}

	/**
	 * Execute when block was destroyed, add specific pizza effects:
	 * - pepperoni - give extra speed
	 * - pepper - give extra jump
	 * - onion - set nausea for each player except destroyer
	 * - garlic - give invisibility
	 * - sausage - give TNT blocks
	 * - olive - give slowbombs
	 * 
	 * @param Block $block
	 * @param CustomPlayer $player
	 */
	public function spleefBlockDestroyed(Block $block, CustomPlayer $player) {
		$id = $block->getId();
		if ($id === Block::STAINED_CLAY) {
			$meta = $block->getDamage();
			if ($meta === 14) { // red
				$player->sendMessage($player->getTranslatedString("PEPPERONI_ITEM"));
				$player->addEffect(Effect::getEffect(Effect::SPEED)->setAmplifier(1)->setDuration(5 * 20)->setVisible(false));
			} else if ($meta === 13) { // green
				$player->sendMessage($player->getTranslatedString("PEPPER_ITEM") . $player->getTranslatedString("JUMP_BONUS", TextFormat::RESET . TextFormat::GREEN . TextFormat::ITALIC));
				$player->addEffect(Effect::getEffect(Effect::JUMP)->setAmplifier(2)->setDuration(10 * 20)->setVisible(false));
			} else if ($meta === 8) { // light gray/purple
				$player->sendMessage($player->getTranslatedString("ONION_ITEM") . $player->getTranslatedString("NAUSE_BONUS", TextFormat::RESET . TextFormat::LIGHT_PURPLE . TextFormat::ITALIC));
				foreach ($this->players as $p) {
					if ($p === $player)
						continue;
					$p->addEffect(Effect::getEffect(Effect::NAUSEA)->setAmplifier(2)->setDuration(10 * 20)->setVisible(false));
				}
			}
		} else if ($id === Block::GLASS) {
			$player->sendMessage($player->getTranslatedString("GARLIC_ITEM"));
			$player->addEffect(Effect::getEffect(Effect::INVISIBILITY)->setDuration(10 * 20)->setAmbient(true));
		} else if ($id === Block::WOODEN_PLANKS) {
			$player->sendMessage($player->getTranslatedString("SAUSAGE_ITEM"));
			if (!is_null($player->tntBonusSlot)) {
				$i = $player->getInventory()->getItem($player->tntBonusSlot);
				if ($i !== null && $i->getId() === Item::TNT) {
					$i->setCount($i->getCount() + 3);
					$player->getInventory()->setItem($player->tntBonusSlot, $i);
					return;
				}
			}
			$player->tntBonusSlot = $player->getInventory()->firstEmpty();
			$player->setHotbarAction($player->tntBonusSlot, new ExplodeItem_1($player->tntBonusSlot, 3));
			
		} else if ($id === Block::COAL_BLOCK) {
			$player->sendMessage($player->getTranslatedString("OLIVE_ITEM"));
			if (!is_null($player->slowBombSlot)) {
				$i = $player->getInventory()->getItem($player->slowBombSlot);
				if ($i !== null && $i->getId() === Item::EMERALD) {
					$i->setCount($i->getCount() + 3);
					$player->getInventory()->setItem($player->slowBombSlot, $i);
					return;
				}
			}
			$player->slowBombSlot = $player->getInventory()->firstEmpty();
			$player->setHotbarAction($player->slowBombSlot, new SlowBombItem($player->slowBombSlot, 3));
		}
	}

}

<?php

namespace Spleef\game\modes\Spleef;

use pocketmine\block\Block;
use pocketmine\entity\Effect;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat;
use Spleef\gadget\NamedItem;
use Spleef\player\CustomPlayer;

/** This class manages Cake Spleef game mode */
class CakeSpleefGame extends SpleefGame {
	/** @var string */
	public static $type = "CakeSpleef";

	/**
	 * Executes when countdown finished. 
	 * Adds iron shovel for all players
	 */
	public function countdownFinished() {
		parent::countdownFinished();
		foreach ($this->players as $player) {
			$player->setHotbarAction(
					0, new NamedItem(Item::IRON_SHOVEL, 4, 1, $player->getTranslatedString("SPOON_ITEM", TextFormat::GOLD))
			);
			$player->setStateInGame();
		}		
	}

	/**
	 * Executes when block destroyed, add specific cake effects:
	 * - jump bonus
	 * - nausea effect for all players except destroyer
	 * 
	 * @param Block $block
	 * @param CustomPlayer $player
	 */
	public function spleefBlockDestroyed(Block $block, CustomPlayer $player) {
		$id = $block->getId();
		if ($id === Block::STAINED_CLAY) {
			$meta = $block->getDamage();
			if ($meta === 6) { // pink
				$player->sendMessage($player->getTranslatedString("JUMP_BONUS", TextFormat::LIGHT_PURPLE));
				$player->addEffect(Effect::getEffect(Effect::JUMP)->setAmplifier(2)->setDuration(5 * 20)->setVisible(false));
			} else if ($meta === 11) { // blue
				$player->sendMessage($player->getTranslatedString("NAUSE_BONUS", TextFormat::BLUE));
				foreach ($this->players as $p) {
					if ($p === $player)
						continue;
					$p->addEffect(Effect::getEffect(Effect::NAUSEA)->setAmplifier(2)->setDuration(10 * 20)->setVisible(false));
				}
			}
		}
	}

}

<?php

namespace Spleef\game;

use pocketmine\block\Block;
use pocketmine\event\TimingsHandler;
use pocketmine\level\Level;
use pocketmine\level\particle\DestroyBlockParticle;
use pocketmine\utils\TextFormat;
use Spleef\gadget\ReturnToLobbyActionItem;
use Spleef\player\CustomPlayer;
use Spleef\Plugin;
use Spleef\Area;
use pocketmine\math\Vector3;
use pocketmine\Player;

/**
 * Base class for a game
 */
class Game {
	/** @var string */
	public static $type = "Unknown";
	/** @var TimingsHandler */
	protected static $loadTimings = null;
	/** @var TimingsHandler */
	protected static $chunkCopyTimings = null;
	/** @var Plugin */
	protected $plugin;
	/** @var GameManager */
	protected $gameManager;
	/** @var int */
	public $noDamageTime = 5; // for how long players won't get hurt after the match actually starts
	/** @var int */
	public $multipleDeaths = 0; // should multiple deaths be allowed: -1 - unlimited, 0 - none, 1 - 1 respawn, 2 - 2 respawns [...]
	/** @var int */
	public $coinsForParticipation = 1; // how many coins should be given for joining the game and finishing it
	/** @var int */
	public $coinsForWinning = 5; // how many coins should be given for winning the game
	/** @var int */
	public $coinsForKill = 2; // how many coins should be given for a single kill
	/** @var int */
	public $coinsForAssist = 1; // how many coins should be given for a single kill assist
	/** @var bool */
	public $allowDroppedItems = true;
	/** @var string */
	public $name;
	/** @var Area */
	public $area;
	/** @var GameMapSourceInfo */
	private $mapSource;
	/** @var CustomPlayer[] */
	public $players = [];
	/** @var CustomPlayer[] */
	public $spectators = [];
	/** @var int */
	public $minPlayers;
	/** @var int */
	public $maxPlayers;
	/** @var bool */
	public $started = false;
	/** @var int */
	public $countdown = -1;
	/** @var array|null */
	public $startingPositions = null;
	/** @var array|null */
	public $avalibleStartingPositions = null;
	/** @var bool */
	public $restarting = false;
	/** @var bool */
	public $private = false; // can players join it?
	/** @var bool */
	public $dataUpdated = false;
	/** @var bool */
	public $isStarted = false;
	
	/**
	 * Sets loadTimings and chunkCopyTimings
	 */
	protected static function initTimings() {
		self::$loadTimings = new TimingsHandler("Game Creation");
		self::$chunkCopyTimings = new TimingsHandler("Chunk Copying");
	}

	/**
	 * Class constructor, save basic game options like allowed number of players,
	 * gametype, spawnpoints
	 * 
	 * @param Plugin $plugin
	 * @param \Spleef\game\GameManager $gameManager
	 * @param string $name
	 * @param Area $gameArea
	 * @param \Spleef\game\GameMapSourceInfo $source
	 * @param int $minPlayers
	 * @param int $maxPlayers
	 */
	public function __construct(Plugin $plugin, GameManager $gameManager, $name, Area $gameArea, GameMapSourceInfo $source, $minPlayers, $maxPlayers) {
		$plugin->getLogger()->info("Created " . $name . " at " . $gameArea->centerX . ", " . $gameArea->centerZ);

		if (self::$loadTimings === null) {
			self::initTimings();
		}

		self::$loadTimings->startTiming();
		$this->plugin = $plugin;
		$this->gameManager = $gameManager;
		$this->name = $name;
		$this->area = $gameArea;
		$this->mapSource = $source;
		$this->minPlayers = $plugin->testing ? 1 : $minPlayers;
		$this->maxPlayers = $maxPlayers;
		$this->lootPositions = [];

		$level = $plugin->level;
		for ($x = ($this->area->centerX - $this->area->size) >> 4; $x <= ($this->area->centerX + $this->area->size) >> 4; $x++) {
			for ($z = ($this->area->centerZ - $this->area->size) >> 4; $z <= ($this->area->centerZ + $this->area->size) >> 4; $z++) {
				$this->loadChunk($level, $x, $z);
			}
		}

		$startingPositions = [];
		foreach ($source->positions as $pos) {
			$startingPositions[] = new Vector3($pos->x + (($gameArea->centerX >> 4) - ($source->pos->x >> 4)) * 16, $source->pos->y, $pos->z + (($gameArea->centerZ >> 4) - ($source->pos->z >> 4)) * 16);
		}
		$this->startingPositions = $startingPositions;
		$this->avalibleStartingPositions = $startingPositions;


		self::$loadTimings->stopTiming();
	}

	/**
	 * Add specified player to the game
	 * 
	 * @param CustomPlayer $player
	 * @param bool $restart
	 * @return boolean
	 */
	public function join(CustomPlayer $player, $restart = false) {
		//join game as spectator
		if ($player->isSpectating) {
			$player->sendMessage($player->getTranslatedString("GAME_PREFIX", TextFormat::GRAY) . $player->getTranslatedString("IS_SPECTATOR", TextFormat::BOLD));
			$player->currentGame = $this;
			$this->area->setAreaFor($player);
			$player->spectate();
			$this->spectators[$player->getName()] = $player;
			return true;
		}
		//join game after start as spectator
		if ($this->started && $this->countdown <= 0) {
			$player->sendMessage($player->getTranslatedString("GAME_PREFIX", TextFormat::RED) . $player->getTranslatedString("GAME_IN_PROGRESS", TextFormat::BOLD));
			$player->currentGame = $this;
			$this->area->setAreaFor($player);
			$player->spectate();
			$this->spectators[$player->getName()] = $player;
			return true;
			//join full game as spectator
		} else if ($this->maxPlayers <= count($this->players) + 1) {
			$player->sendMessage($player->getTranslatedString("GAME_PREFIX", TextFormat::RED) . $player->getTranslatedString("PLAYER_LIMIT_ERROR", TextFormat::BOLD));
			$player->currentGame = $this;
			$this->area->setAreaFor($player);
			$player->spectate();
			$this->spectators[$player->getName()] = $player;
			return true;
			//try to join as active player
		} else {
			$found = false;
			foreach ($this->avalibleStartingPositions as $posId => $pos) {
				$this->area->setAreaFor($player, $pos->add(0.5, 0, 0.5));
				unset($this->avalibleStartingPositions[$posId]);
				$player->gameStartingPos = $posId;
				$found = true;
				break;
			}
			//inform player if coudn't join
			if (!$found) {
				$this->plugin->getLogger()->debug(TextFormat::RED . "Couldn't find starting position for " . $player->getPlayer() . " [" . $this->name . "]");
				$player->sendMessage($player->getTranslatedString("ERROR_PREFIX", TextFormat::RED) . $player->getTranslatedString("NO_START_POSITION", TextFormat::BOLD));
				return false;
			}
		}
		//cannot join while restarting
		if ($restart) {
			return false;
		}
		//after successful join send logs and messages
		$this->plugin->getLogger()->info($player->getName() . " joined " . $this->name);
		$this->players[$player->getName()] = $player;
		$this->broadcastMessageLocalized("JOIN_PREFIX", array(), TextFormat::GRAY, $player->getDisplayName());
		$player->currentGame = $this;

		$actions = [
			1 => new ReturnToLobbyActionItem()
		];

		$player->setHotbarActions($actions);
		//wait for another players if needs
		if (!$this->started) {
			$player->showNotification($player->getTranslatedString("PLAYER_WAIT", TextFormat::YELLOW), -1);
		} else {
			$player->showNotification(null);

			if (count($this->players) >= $this->maxPlayers) {
				if ($this->countdown >= 3) {
					$this->countdown = 3;
				}
			}
		}
		//start game
		if (!$this->started && count($this->players) >= $this->minPlayers) {
			$this->start();
		}

		return true;
	}

	/**
	 * Remove player from the game:
	 * - unset him from game data,
	 * - log reason,
	 * - stop, destroy or finish game if needs
	 * 
	 * @param CustomPlayer $player
	 * @return type
	 */
	public function leave(CustomPlayer $player) {
		if (isset($this->players[$player->getName()])) {
			unset($this->players[$player->getName()]);
			$this->broadcastMessageLocalized("QUIT_PREFIX", array(), TextFormat::GRAY, $player->getDisplayName());
			$this->plugin->getLogger()->info($player->getName() . " left " . $this->name);
			if ($player->gameStartingPos !== -1) {
				$this->avalibleStartingPositions[$player->gameStartingPos] = $this->startingPositions[$player->gameStartingPos];
				$player->gameStartingPos = -1;
			} else {
				$this->plugin->getLogger()->error("Player left a game without a starting position set!");
			}

			if ($this->started && $this->countdown > 0) {
				if (count($this->players) < $this->minPlayers) {
					// stop the game!
					$this->started = false;
					$this->countdown = -1;
					$this->broadcastNotification("PLAYER_WAIT");
				}
			}
			if ($this->started && $this->countdown <= 0) {
				$this->finishGame($player);
				return;
			}
		}
		if (isset($this->spectators[$player->getName()])) {
			unset($this->spectators[$player->getName()]);
			$this->broadcastMessageLocalized("QUIT_PREFIX", array(), TextFormat::GRAY, $player->getDisplayName());
		}

		if (count($this->players) === 0) {
			$this->destroy();
		}
	}

	/**
	 * Handles game finish:
	 * - inform about winner,
	 * - give coins,
	 * - destroy game
	 * 
	 * @param CustomPlayer $player
	 * @param bool $won
	 */
	public function finishGame(CustomPlayer $player, $won = false) {
		if ($won) {
			$this->broadcastMessageLocalized("PLAYER_WON", array($player->getName(), $this->plugin->serverGameType), TextFormat::GOLD);
		}

		$player->sendMessage(TextFormat::GOLD . TextFormat::STRIKETHROUGH . "==================================");
		if ($won) {
			$player->sendMessage(TextFormat::BOLD . TextFormat::YELLOW . $player->getTranslatedString("YOU_WON"));
		} else {
			$player->sendMessage(TextFormat::BOLD . $player->getTranslatedString("GAME_RESULTS"));
			$player->showNotification($player->getTranslatedString("YOU_DIED"), 2);
		}

		$coins = $this->finishGameCoinsInfo($player, $this->coinsForParticipation, "participation");
		$coins += $this->finishGameCoinsInfo($player, $this->coinsForWinning, "winning the game", $won);
		$coins += $this->finishGameCoinsInfo($player, $coins, "being a VIP", $player->isVip());
		$player->sendMessage($player->getTranslatedString("TOTAL_RESULT", TextFormat::YELLOW) . TextFormat::BOLD . TextFormat::GOLD . $coins . TextFormat::RESET . TextFormat::YELLOW . $player->getTranslatedString("JUST_COINS"));
		$player->addCoins($coins);

		$player->sendMessage(TextFormat::GOLD . TextFormat::STRIKETHROUGH . "==================================");

		if (!$won) {
			if (count($this->players) === 1) {
				foreach ($this->players as $winner) {
					$this->finishGame($winner, true);
					$this->destroy();
					break;
				}
			} else if (count($this->players) <= 0) {
				$this->destroy();
			}
		}
	}

	/**
	 * Add coins to player on game finish, send info message
	 * 
	 * @param Player $player
	 * @param int $coins
	 * @param int $for
	 * @param bool $add
	 * @return int
	 */
	private function finishGameCoinsInfo(Player $player, $coins, $for, $add = true) {
		if ($add && $coins > 0) {
			$coins = round($coins);
			$player->sendMessage(TextFormat::BOLD . TextFormat::GOLD . "+" . $coins . TextFormat::RESET . $player->getTranslatedString("PREP_FOR") . $for);
			return $coins;
		}
		return 0;
	}

	/**
	 * Start the game, set countdown
	 */
	public function start() {
		$this->started = true;
		$this->countdown = $this->plugin->gameCountdown;
	}

	/**
	 * Forces game starting by the $player
	 * 
	 * @param Player $player
	 */
	public function forceStart($player) {
		if ($player !== null && $player instanceof Player) {
			$this->broadcastMessageLocalized("GAME_STARTED_BY", array($player->getName()), TextFormat::GOLD);
		} else {
			$this->broadcastMessageLocalized("GAME_WAS_STARTED", array(), TextFormat::GOLD);
		}
		if ($this->started) {
			if ($this->countdown > 3) {
				$this->countdown = 3;
			}
		} else {
			$this->start();
		}
	}

	/**
	 * Destroy and restart the game, return all players to the lobby
	 */
	public function destroy() {
		foreach ($this->players as $id => $player) {
			unset($this->players[$id]);
			$player->currentGame = null;
			$player->returnToLobby();
		}
		foreach ($this->spectators as $id => $player) {
			unset($this->spectators[$id]);
			$player->currentGame = null;
			$player->returnToLobby();
		}

		$this->restarting = true;

		$level = $this->plugin->level;
		
		for ($x = ($this->area->centerX - $this->area->size) >> 4; $x <= ($this->area->centerX + $this->area->size) >> 4; $x++) {
			for ($z = ($this->area->centerZ - $this->area->size) >> 4; $z <= ($this->area->centerZ + $this->area->size) >> 4; $z++) {
				$chunk = $level->getChunk($x, $z);
				$chunk->allowUnload = true;
				//$level->unloadChunk($x, $z, false);
			}
		}

		$this->restarting = false;

		$this->gameManager->destroy($this);

		$this->plugin->getLogger()->info("Destroyed " . $this->name);
	}

	// events

	/**
	 * Initializes when player moves inside current game before game start
	 * 
	 * @param PlayerMoveEvent $event
	 */
	public function onPlayerMove($event) {
		if (!isset($this->players[$event->getPlayer()->getName()])) {
			return;
		}

		$spectating = $event->getPlayer()->isSpectating;
		if (!$spectating && (!$this->started || $this->countdown > 0)) {
			if ($event->getPlayer()->gameStartingPos === -1) {
				return;
			}
			$startingPos = $this->startingPositions[$event->getPlayer()->gameStartingPos];
			if (round($startingPos->x + 0.5) !== round($event->getTo()->x) ||
					round($startingPos->y) !== round($event->getTo()->y) ||
					round($startingPos->z + 0.5) !== round($event->getTo()->z)
			) {
				$event->getPlayer()->teleport($startingPos->add(0.5, 0, 0.5));
			}
		}
	}


	public function countdownFinished() {}

	/**
	 * Handles player death event,
	 * set him as spectator (if more than 2 players were in game) 
	 * or teleport to lobby (if game finished)
	 * 
	 * @param CustomPlayer $player
	 * @param string $damageName
	 */
	public function playerDied(CustomPlayer $player, $damageName) {
		$this->broadcastMessageLocalized("PLAYER_WAS_KILLED", array($player->getName(), $damageName));
		if (count($this->players) > 2) {
			$player->teleport(new Vector3($player->x, 100, $player->z));
			$player->spectate();

			if ($player->gameStartingPos !== -1) {
				$this->avalibleStartingPositions[$player->gameStartingPos] = $this->startingPositions[$player->gameStartingPos];
				$player->gameStartingPos = -1;
			}
		} else {
			$player->returnToLobby();
		}
	}

	/**
	 * Send localized message to everybody inside arena
	 * 
	 * @param string $msg
	 * @param array $args
	 * @param string $prefix
	 * @param string $suffix
	 */
	public function broadcastMessageLocalized($msg, $args = array(), $prefix = "", $suffix = "") {
		foreach ($this->players as $player) {
			$player->sendLocalizedMessage($msg, $args, $prefix, $suffix);
		}
		foreach ($this->spectators as $player) {
			$player->sendLocalizedMessage($msg, $args, $prefix, $suffix);
		}
	}

	/**
	 * broadcast message function (use for strings not needed in localization)
	 * 
	 * @param type $msg
	 */
	public function broadcastMessage($msg) {
		$this->plugin->getLogger()->info("[" . $this->name . "] " . $msg);
		foreach ($this->players as $player) {
			$player->sendMessage($msg);
		}
		foreach ($this->spectators as $player) {
			$player->sendMessage($msg);
		}
	}

	/**
	 * Show notifications for all players inside arena
	 * 
	 * @param string $msg
	 * @param number $time
	 * @param array $args
	 * @param string $prefix
	 * @param string $suffix
	 */
	public function broadcastNotification($msg, $time = -1, $args = array(), $prefix = "", $suffix = "") {
		foreach ($this->players as $player) {
			$player->showNotification($player->getTranslatedString($msg, $prefix, $args, $suffix), $time);
		}
		foreach ($this->spectators as $player) {
			$player->showNotification($player->getTranslatedString($msg, $prefix, $args, $suffix), $time);
		}
	}	

	/**
	 * Loads chunk
	 * 
	 * @param Level $level
	 * @param int $x
	 * @param int $z
	 */
	protected function loadChunk(Level $level, $x, $z) {
		$centerX = $this->area->centerX >> 4;
		$centerZ = $this->area->centerZ >> 4;
		$dX = $x - $centerX;
		$dZ = $z - $centerZ;
		$sX = ($this->mapSource->pos->x >> 4) + $dX;
		$sZ = ($this->mapSource->pos->z >> 4) + $dZ;
		$this->copySourceChunk($level, (int) $sX, (int) $sZ, (int) $x, (int) $z);
	}

	/**
	 * Copy chunk and add it to the level
	 * 
	 * @param Level $level
	 * @param int $srcX
	 * @param int $srcZ
	 * @param int $destX
	 * @param int $destZ
	 * @return type
	 */
	protected function copySourceChunk(Level $level, $srcX, $srcZ, $destX, $destZ) {
		self::$chunkCopyTimings->startTiming();
		$hash = Level::chunkHash($srcX, $srcZ);
		$data = $this->mapSource->chunks[$hash];
		if ($data === null){
			return;
		}
		$c = GameChunk::fromData($destX, $destZ, $data[0], $data[1], $data[3], $data[2], $data[4], $data[5]);
		$level->setChunk($destX, $destZ, $c, false);
		self::$chunkCopyTimings->stopTiming();
	}

	/**
	 * Destroy block
	 * 
	 * @param Level $level
	 * @param Vector3 $pos
	 * @param bool $drops
	 */
	public function destroyBlock(Level $level, Vector3 $pos, $drops = false) {
		$b = $level->getBlock($pos);

		$players = $level->getUsingChunk($b->x >> 4, $b->z >> 4);
		$level->addParticle(new DestroyBlockParticle($b->add(0.5, 0.5, 0.5), $b), $players);

		$level->setBlock($pos, Block::get(Block::AIR), true);
	}

}

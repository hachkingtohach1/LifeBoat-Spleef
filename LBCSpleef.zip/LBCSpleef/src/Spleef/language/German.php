<?php


namespace Spleef\language;

use pocketmine\utils\TextFormat;
use LbCore\language\Translate;
use LbCore\language\core\German as LbGerman;

class German extends LbGerman {
	
	/**
	 * Merge LbCore base translations with custom plugin translates
	 */
	public function __construct() {
		$this->translates["ERROR_PREFIX"] = "Fehler>";
		$this->translates["GAME_PREFIX"] = "Spiel>";
		$this->translates["STOP_PREFIX"] = "Stop>";
		$this->translates["CHAT_PREFIX"] = "Chat>";
		$this->translates["JOIN_PREFIX"] = "Join>";
		$this->translates["QUIT_PREFIX"] = "Quit>";
		$this->translates["KIT_PREFIX"] = "Kit>";
		$this->translates["WARNING_PREFIX"] = "§cWarnung>";
		$this->translates["PUNISH_PREFIX"] = "Bestrafung>";
		$this->translates["WELCOME_TO_LIFEBOAT"] = "§aWillkommen auf Lifeboat arg1!";
		$this->translates["PURCHASED_ITEM"] = "§aKauf> Erfolgreich gekauft:";
		$this->translates["ALREADY_PURCHASED"] = "§cDu hast dieses Item bereits gekauft!";
		$this->translates["GADGET_FOR_VIP"] = "Dieses Item ist nur für VIPs";
		$this->translates["WAITING"] = "Bitte warte...";
		$this->translates["NOT_PURCHASED_ITEM"] = "§cDu hast dieses Item noch nicht gekauft!\n§fUm es zu kaufen, klicke nochmal.";
		$this->translates["PREP_FOR"] = "für";
		$this->translates["CAN_BUY"] = "Du hast keine arg1!\n Du kannst arg2 §e für arg3 Coins kaufen,\n§eindem du nochmal klickst.";
		$this->translates["SEND_POTATO"] = "Du hast jemanden kartoffelt:";
		$this->translates["GET_POTATO"] = "Du wurdest kartoffelt von";
		$this->translates["IS_SPECTATOR"] = "Du bist ein Spectator.";
		$this->translates["GAME_IN_PROGRESS"] = "Dieses Spiel ist am laufen.";
		$this->translates["PLAYER_LIMIT_ERROR"] = "Dieses Spiel hat seine maximale Spieler-Anzahl erreicht.";
		$this->translates["NO_START_POSITION"] = "Kann die Startposition nicht finden!";
		$this->translates["PLAYER_WAIT"] = "§eWarte auf Spieler...";
		$this->translates["YOU_WON"] = "Du hast das Spiel gewonnen!";
		$this->translates["GAME_RESULTS"] = "§9> §7Ergebnisse:";
		$this->translates["YOU_DIED"] = "§cDu bist gestorben!";
		$this->translates["TOTAL_RESULT"] = "Total:";
		$this->translates["PLAYER_WON"] = "arg1 hat ein arg2 Spiel gewonnen!";
		$this->translates["GAME_STARTED_BY"] = "Spiel> Das Spiel wurde von arg1 gestartet";
		$this->translates["GAME_WAS_STARTED"] = "Spiel> Das Spiel wurde gestarted.";
		$this->translates["PLAYER_WAS_KILLED"] = "§carg1 wurde von arg2 getötet";
		$this->translates["START_POSITION_ERROR"] = "Kann deine Startposition nicht finden!";
		$this->translates["GAME_STARTED_GOOD_LUCK"] = "Spiel> Das Spiel ist gestartet, viel Glück!";
		$this->translates["STARTING_GAME_COUNTDOWN"] = "Starte in arg1 Sekunden...";
		$this->translates["NO_GAME"] = "Das Spiel arg1 existiert nicht!";
		$this->translates["ON_GAME"] = "Du bist schon auf arg1!";
		$this->translates["IN_GAME"] = "Du bist nun in: arg1";
		$this->translates["SPOON_ITEM"] = "Löffel";
		$this->translates["JUMP_BONUS"] = "Du kannst für die nächsten 10 Sekunden höher springen!";
		$this->translates["NAUSE_BONUS"] = "Allen anderen ist für 10 Sekunden übel!";
		$this->translates["SHOVEL_ITEM"] = "Spleef Schaufel";
		$this->translates["PIZZA_CUTTER"] = "Pizzaschneider";
		$this->translates["PEPPERONI_ITEM"] = "§c§lPepperoni!§r§c§o Du bist für die nächsten 5 Sekunden schneller!";
		$this->translates["PEPPER_ITEM"] = "§a§lPfeffer!";
		$this->translates["ONION_ITEM"] = "§d§lZwiebel";
		$this->translates["GARLIC_ITEM"] = "§f§lKnoblauch!§r§f§o Du bist für die nächsten 10 Sekunden unsichtbar!";
		$this->translates["SAUSAGE_ITEM"] = "§c§lWurst!§r§c§o Du hast 3 Bomben erhalten!";
		$this->translates["OLIVE_ITEM"] = "§c§lOlive!§r§c§o Du hast 3 Langsamkeits-Bomben erhalten!";
		$this->translates["BOMB_WORKS"] = "Du hast arg1 Spieler für 5 Sekunden verlangsamt!";
		$this->translates["JUST_COINS"] = "Coins";
		$this->translates["ACC_NOT_REGISTERED"] = "§9> §7Dieser Account ist nicht registriert.";
		$this->translates["PLACE_BLOCK_ERROR"] = "Du kannst hier keine Blöcke setzen.";
		$this->translates["YOU_TELEPORTED"] = "Du wurdest teleportiert zu:";
		$this->translates["BASE_ERROR"] = "Ein Fehler ist aufgetreten.";
	}
	
}

<?php


namespace Spleef\language;

use pocketmine\utils\TextFormat;
use LbCore\language\Translate;
use LbCore\language\core\English as LbEnglish;

class English extends LbEnglish {
	
	/**
	 * Merge LbCore base translations with custom plugin translates
	 */
	public function __construct() {
		$this->translates = array_merge($this->translates, $this->spTranslates);
	}

	private  $spTranslates = array(
		"ERROR_PREFIX" => "Error> ",
		"GAME_PREFIX" => "Game> ",
		"STOP_PREFIX" => "Stop> ",	 
		"CHAT_PREFIX" => "Chat> ",
		"JOIN_PREFIX" => "Join> ",
		"QUIT_PREFIX" => "Quit> ",
		"KIT_PREFIX" => "Kit> ",
		"WARNING_PREFIX" => TextFormat::RED . "Warning> ",
		"PUNISH_PREFIX" => "Punish> ",
//		"CURRENT_GAME" => "You are currently on: ",
//		"PLAYER_NOT_FOUND" => "Cannot find player: ",
//		"COMMAND_IN_GAME" => "You must run this command in-game",
//		"STARTING_GAME" => "Starting...",	
//		"WHITE" => "Whitelist:",
		"WELCOME_TO_LIFEBOAT" => TextFormat::GREEN . "Welcome to Lifeboat arg1!",
		"PURCHASED_ITEM" => TextFormat::GREEN . "Purchase> You have purchased the ",
		"ALREADY_PURCHASED" => TextFormat::RED . "You have already purchased this item!",
		"GADGET_FOR_VIP" => "This item is only available to VIPs.",
		"WAITING" => "Please wait...",
		"NOT_PURCHASED_ITEM" => TextFormat::RED . "You haven't purchased this item yet!\n" 
							. TextFormat::GRAY . "To purchase this item, tap it again.",
		"PREP_FOR" => " for ", 
//		"COINS" => " coins",
		"CAN_BUY" => TextFormat::YELLOW . "You don't have any arg1!\n You can buy arg2 "
					. TextFormat::YELLOW . " for arg3 coins\n" 
					. TextFormat::YELLOW . "by pressing the screen again.",
		"SEND_POTATO" => "You potatoed ",
		"GET_POTATO" => "You got potatoed by ",
//		"NOT_WHITE_ERROR" => "You are not white-listed on this server!",
//		"BANNED_ERROR" => "You are banned from this server!",
		"IS_SPECTATOR" => "You are a spectator.",
		"GAME_IN_PROGRESS" => "This game is in progress.",
		"PLAYER_LIMIT_ERROR" => "This game has reached it's max player count.",
		"NO_START_POSITION" => "Cannot find starting position!",
		"PLAYER_WAIT" => TextFormat::YELLOW . "Waiting for players...",
		"YOU_WON" => "You have won the game!",
		"GAME_RESULTS" => Translate::PREFIX_SYSTEM_MESSAGE . "Results:",
		"YOU_DIED" => TextFormat::RED . "You died!",
		"TOTAL_RESULT" => "Total: ",
//		"WAS_KILLED" => " was killed",
		"PLAYER_WON" => "arg1 has won a arg2 game!",
		"GAME_STARTED_BY" => "Game> Game was started by arg1",
		"GAME_WAS_STARTED" => "Game> Game was started.",
		"PLAYER_WAS_KILLED" => TextFormat::RED . "arg1 was killed by arg2",
		"START_POSITION_ERROR" => "Cannot find your starting position!",
		"GAME_STARTED_GOOD_LUCK" => "Game> The game has started! Good luck!",
		"STARTING_GAME_COUNTDOWN" => "Starting in arg1 seconds...",
		"NO_GAME" => "Game arg1 doesn't exist!",
		"ON_GAME" => "You are already on arg1!",
		"IN_GAME" => "You are now in: arg1",

		"SPOON_ITEM" => "Spoon",
		"JUMP_BONUS" => "You can jump higher for the next 10 seconds!",
		"NAUSE_BONUS" => "Everyone else is nauseaous for 10 seconds!",
		"SHOVEL_ITEM" => "Spleef Shovel",
		"PIZZA_CUTTER" => "Pizza Cutter",
		"PEPPERONI_ITEM" => TextFormat::RED . TextFormat::BOLD . "Pepperoni!" 
							. TextFormat::RESET . TextFormat::RED . TextFormat::ITALIC 
							. " You are faster for the next 5 seconds!",
		"PEPPER_ITEM" => TextFormat::GREEN . TextFormat::BOLD . "Pepper!",
		"ONION_ITEM" => TextFormat::LIGHT_PURPLE . TextFormat::BOLD . "Onion",
		"GARLIC_ITEM" => TextFormat::WHITE . TextFormat::BOLD . "Garlic!" 
						. TextFormat::RESET . TextFormat::WHITE . TextFormat::ITALIC
						. " You are invisible for the next 10 seconds!",
		"SAUSAGE_ITEM" => TextFormat::RED . TextFormat::BOLD . "Sausage!" 
						. TextFormat::RESET . TextFormat::RED . TextFormat::ITALIC 
						. " You received 3 explosives!",
		"OLIVE_ITEM" => TextFormat::RED . TextFormat::BOLD . "Olive!" 
						. TextFormat::RESET . TextFormat::RED . TextFormat::ITALIC 
						. " You received 3 slow bombs!",
		"BOMB_WORKS" => "You slowed down arg1 players for 5 seconds!",
		"JUST_COINS" => " coins",
		"ACC_NOT_REGISTERED" => Translate::PREFIX_SYSTEM_MESSAGE . "This account is not registered.",
		"PLACE_BLOCK_ERROR" => "You can't place blocks here.",
//		"BREAK_BLOCK_ERROR" => "You can't break blocks here.",
		"YOU_TELEPORTED" => "You were teleported to: ",
		"BASE_ERROR" => "An error has occurred."
	);
	
}

<?php

namespace Spleef;

use Spleef\player\CustomPlayer;
use pocketmine\math\Vector3;

/**
 * Manages Areas in the world
 * lobby and each map are instances of Area
 */
class Area {
	/* @var Plugin */
	private $plugin;
	/* @var int */
	public $centerX;
	/* @var int */
	public $y;
	/* @var int */
	public $centerZ;
	/* @var int */
	public $size;
	/* @var int */
	public $kickSize;
	/* @var bool*/
	public $canPlaceBreak;
	/* @var int */
	public $time;
	/* @var bool - for cycle reload of game mode */
	public $doCycle;
	/* @var bool - for invincibility in lobby */
	public $noDamage;

	/**
	 * Area constructor, save all nesessary fields from args
	 * 
	 * @param \Spleef\Plugin $plugin
	 * @param type $centerX
	 * @param type $y
	 * @param type $centerZ
	 * @param type $size
	 * @param type $kickSize
	 * @param type $canPlaceBreak
	 * @param type $time
	 * @param type $doCycle
	 * @param type $noDamage
	 */
	public function __construct(
			Plugin $plugin, 
			int $centerX, 
			int $y, 
			int $centerZ, 
			int $size, 
			int $kickSize, 
			bool $canPlaceBreak = false, 
			int $time = 1200, 
			bool $doCycle = false, 
			bool $noDamage = false) {
		$this->plugin = $plugin;
		$this->centerX = $centerX;
		$this->y = $y;
		$this->centerZ = $centerZ;
		$this->size = $size / 2;
		$this->kickSize = $kickSize / 2;
		$this->canPlaceBreak = $canPlaceBreak;
		$this->time = $time;
		$this->doCycle = $doCycle;
		$this->noDamage = $noDamage;
	}

	/**
	 * Sets health and teleports the specified player to place on current arena
	 * 
	 * @param CustomPlayer $player
	 * @param Vector3 $newPos
	 */
	public function setAreaFor(CustomPlayer $player, $newPos = NULL) {
		$player->currentArea = $this;
		if (!isset($newPos) || $newPos === null) {
			$newPos = new Vector3($this->centerX, $this->y, $this->centerZ);
		}

		$player->teleport($newPos);

		$player->setHealth(20);
	}

	/**
	 * Returns $this->canPlaceBreak
	 * Use it to get block actions availability from other classes
	 * 
	 * @return bool
	 */
	public function canPlaceBreakBlocks() {
		return $this->canPlaceBreak;
	}

	/**
	 * Returns true if passed coordinates located in $this area
	 * 
	 * @param int $x
	 * @param int $z
	 * @return bool
	 */
	public function inArea($x, $z) {
		return ($x > $this->centerX - $this->kickSize && $z > $this->centerZ - $this->kickSize &&
				$x < $this->centerX + $this->kickSize && $z < $this->centerZ + $this->kickSize);
	}

}
